import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 This class is responsible for initializing the rectangle that is used for a player movable object
 */
public class Avatar{
    
    //Constructor for the class
    public Avatar(){}
    
    //Draws the rectangle to be used
    public ImageView avatar_Snake(int x, int y){
    		Image player = new Image("Player.gif");
	    ImageView player_Ava = new ImageView(player);
	    player_Ava.setFitWidth(x);
        player_Ava.setFitHeight(y);
        return player_Ava;
    }
    
}
