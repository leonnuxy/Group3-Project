import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.*;
import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyCode;
import java.util.Random;


/**
 This class initializes the window for a snake game to be played in including the movement and timers
 */
public class Window3 extends Application{
    public int score;
    boolean R = false;
    boolean L = false;
    boolean U = false;
    boolean D = false;
    double rectX=0;
    double rectY=0;
    Random rand = new Random();
    boolean check = true;
    Group space = new Group();
	private ImageView theCollectible;
	private ImageView theObstacle;
    
    
    /* Starts the window */
    public void start(Stage primaryStage){
        Scene scene = new Scene(play(), 500, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    /* Produces the shape from avatar class to move and the controls to be used to move it */
    public Group play(){
        //Avatar ava = new Avatar();
        Collectible col = new Collectible();
        theCollectible = col.getCol();
        Border bor = new Border();
        Obstacle obs = new Obstacle();
        theObstacle = obs.getObs();
        Button controls = new Button();
        Label label_score = new Label("Your score is: " + score);
        Avatar new_player = new Avatar();
        ImageView player = new_player.avatar_Snake(20, 20);
        
        
        player.relocate(30, 30);
        theCollectible.relocate(col.setXPos2(), col.setYPos2());
        theObstacle.relocate(obs.setXPos(), obs.setYPos());
        label_score.relocate(20, 240);
        controls.relocate(-50, 100);
        space.getChildren().add(label_score);
        space.getChildren().add(bor.leftBorder());
        space.getChildren().add(bor.rightBorder());
        space.getChildren().add(bor.downBorder());
        space.getChildren().add(bor.upBorder());
        space.getChildren().add(player);
        space.getChildren().add(theCollectible);
        space.getChildren().add(theObstacle);
        space.getChildren().add(controls);
        
        //controls event handler
        controls.setOnKeyPressed(e->{
            if(e.getCode()==KeyCode.RIGHT){
                R=true;
                L=false;
                U=false;
                D=false;
            }
            
            if(e.getCode()==KeyCode.LEFT){
                L=true;
                R=false;
                D=false;
                U=false;
            }
            
            if(e.getCode()==KeyCode.UP){
                L=false;
                R=false;
                U=true;
                D=false;
            }
            
            if(e.getCode()==KeyCode.DOWN){
                R=false;
                L=false;
                D=true;
                U=false;
            }
        });
        
        //Animates the movement
        AnimationTimer animate=new AnimationTimer(){
            //handler for the animation of the movement
            public void handle(long arg0) {
                if(R){
                    rectX+=2.2;
                    player.setTranslateX(rectX);
                }
                
                if(L){
                    rectX-=2.2;
                    player.setTranslateX(rectX);
                }
                
                if(U){
                    rectY-=2.2;
                    player.setTranslateY(rectY);
                }
                
                if(D){
                    
                    rectY+=2.2;
                    
                    player.setTranslateY(rectY);
                    
                }
                
                //collision between player controlled object and borders
                if ((player.getBoundsInParent().intersects(theObstacle.getBoundsInParent()))||
                    (player.getBoundsInParent().intersects(bor.borLXPos, bor.borLYPos, bor.borLWidth, bor.borLHeight))||
                    (player.getBoundsInParent().intersects(bor.borRXPos, bor.borRYPos, bor.borRWidth, bor.borRHeight)) ||
                    (player.getBoundsInParent().intersects(bor.borUXPos, bor.borUYPos, bor.borUWidth, bor.borUHeight)) ||
                    (player.getBoundsInParent().intersects(bor.borDXPos, bor.borDYPos, bor.borDWidth, bor.borDHeight))){
                    
                    label_score.setText("You Died");
                    System.exit(0);
                }
                
                //collision between player controlled objects and collectible
                if (player.getBoundsInParent().intersects(theCollectible.getBoundsInParent())) {
                    theCollectible.relocate(col.setXPos2(), col.setYPos2());
                    theCollectible.getBoundsInParent();
                    space.getChildren().remove(theCollectible);
                    space.getChildren().add(theCollectible);
                    score++;
                    label_score.setText("Your score is: " + score);
                }
            }
        };
        animate.start();
        return space;
    }
    
    /* Launch all arguments */
    public static void main(String[] args){
        
        launch(args);
    }
}